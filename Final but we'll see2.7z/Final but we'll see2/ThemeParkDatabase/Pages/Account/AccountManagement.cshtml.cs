﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using ThemeParkDatabase.Data;

namespace ThemeParkDatabase.Pages.Account
{
    public class AccountManagementModel : PageModel
    {
        private readonly ThemeParkDatabase.Data.ApplicationDbContext _appContext;
        private readonly ThemeParkDatabase.Models.ThemeParkDatabaseContext _context;

        public AccountManagementModel(ThemeParkDatabase.Models.ThemeParkDatabaseContext context,
            ThemeParkDatabase.Data.ApplicationDbContext appContext)
        {
            _context = context;
            _appContext = appContext;
        }

        public IList<ApplicationUser> Account { get; set; }

        public async Task OnGet()
        {
            Account = await _appContext.Users.ToListAsync();
        }
    }
}