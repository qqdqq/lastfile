using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ThemeParkDatabase.Pages.Account
{
    public class LockoutModel : PageModel
    {
        public void OnGet()
        {

        }
    }
}
